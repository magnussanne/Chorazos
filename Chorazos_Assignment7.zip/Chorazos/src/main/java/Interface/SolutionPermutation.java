package Interface;

public interface SolutionPermutation {
    double getEnergy();
    void modify(int NUMBER_CHANGES);
}
