package Interface;

public interface Project {
    String getTitle();
    Focus getFocus();
}
