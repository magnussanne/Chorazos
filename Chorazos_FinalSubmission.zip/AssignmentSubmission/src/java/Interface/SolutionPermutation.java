package Interface;

public interface SolutionPermutation {
    double getEnergy(double gpaImportance);
    void modify(int NUMBER_CHANGES);
}
